const s="/assets/mirror_back-e0062292.png",a="/assets/girl_final-8df47069.png";export{s as _,a};
